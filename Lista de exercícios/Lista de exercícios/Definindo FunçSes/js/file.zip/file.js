function olaMundo(){
    alert("Olá Mundo");
}

function mostrarNome(){
    let nome = prompt("Digite seu nome");
    console.log(`${nome}`);
}

function concatenaPalavras(){
    let p1 = prompt("Digite uma palavra");
    let p2 = prompt("Digite outra palavra");
    console.log("Palavras concatenadas:" + p1 + p2);
}